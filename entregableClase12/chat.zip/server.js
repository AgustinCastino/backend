const express = require('express')
const {Server: HttpServer} = require('http')
const {Server:IOServer} = require('socket.io')

const app = express()
const httpServer = new HttpServer(app)
const io = new IOServer(httpServer)

app.use(express.static('./public'))

app.get('/', (req,res)=>{
    res.sendFile('index.html',{root: __dirname})
})

httpServer.listen(8080,(req,res)=>{
    console.log('Servidor Iniciado');
})

const mensajes = [{
    author: 'Agus', message: 'Hola que tal'
}]

io.on('connection', (socket)=>{
    console.log('Cliente nuevo conectado');

    socket.emit('messages', mensajes)

    socket.on('new-message', data =>{
        mensajes.push(data)

        io.sockets.emit('messages', mensajes)
    })
})
